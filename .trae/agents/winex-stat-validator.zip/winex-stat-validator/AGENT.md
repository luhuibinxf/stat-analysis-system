---
name: "winex-stat-validator"
description: "WiNEX检查统计验证Agent - 连接WiNEX_PACS数据库，自动执行SQL查询，生成统计报告并与前台数据验证。适用于放射科、内镜科等工作量统计和数据核对。"
version: "1.2.0"
author: "AI Assistant"
created: "2026-04-23"
updated: "2026-04-23"
---

# WiNEX 统计验证 Agent

## 快速统计（无需记忆Schema）

### 最少2日验证要求

**重要**：任何一个统计任务，都必须进行最少2日数据验证。

#### 验证步骤
```
第1步：选择验证日期（目标日期 + 额外1天）
第2步：执行目标日期统计 → 验证组内公式
第3步：执行额外日期统计 → 验证组内公式
第4步：对比两日数据 → 确保逻辑一致
第5步：生成验证报告 → 输出完整结果
```

---

## 数据库Schema（快速参考）

### 表结构

| 表名 | 说明 | 关键字段 |
|------|------|----------|
| EXAM_TASK | 检查任务主表 | EXAM_TASK_ID, SYSTEM_SOURCE_NO, REGISTER_AT, EXAM_TASK_STATUS |
| EXAM_REPORT | 检查报告表 | EXAM_TASK_ID, REPORTER_NAME |
| EXAM_CHARGE_ITEM | 收费项目表 | EXAM_TASK_ID, EXAM_ITEM_NAME |

### 常用字段

| 字段 | 说明 |
|------|------|
| SYSTEM_SOURCE_NO | 放射科=RIS, 内镜科=EIS, 超声科=UIS |
| EXAM_TASK_STATUS | 状态 >= 50 表示已完成 |
| REGISTER_AT | 登记时间（统计用这个） |
| EXAM_CATEGORY_NAME | 检查类别名称（放射科统计用） |
| EXAM_ITEM_NAME | 检查项目名称（内镜科统计用） |
| REPORTER_NAME | 报告医生姓名 |

---

## 快速SQL模板

### 1. 总数据量
```sql
-- 替换 @system 和 @date 即可
SELECT COUNT(*) FROM EXAM_TASK t
JOIN EXAM_REPORT r ON t.EXAM_TASK_ID = r.EXAM_TASK_ID
WHERE t.IS_DEL=0 AND r.IS_DEL=0
  AND t.SYSTEM_SOURCE_NO='@system'
  AND t.EXAM_TASK_STATUS>=50
  AND CAST(t.REGISTER_AT AS DATE)='@date'
  AND r.REPORTER_NAME IS NOT NULL;
```

### 2. 按检查类别统计（放射科用）
```sql
SELECT t.EXAM_CATEGORY_NAME, COUNT(*) AS Count
FROM EXAM_TASK t
JOIN EXAM_REPORT r ON t.EXAM_TASK_ID = r.EXAM_TASK_ID
WHERE t.IS_DEL=0 AND r.IS_DEL=0
  AND t.SYSTEM_SOURCE_NO='@system'
  AND t.EXAM_TASK_STATUS>=50
  AND CAST(t.REGISTER_AT AS DATE)='@date'
  AND r.REPORTER_NAME IS NOT NULL
GROUP BY t.EXAM_CATEGORY_NAME
ORDER BY Count DESC;
```

### 3. 按医生分组统计
```sql
SELECT r.REPORTER_NAME, COUNT(*) AS Count
FROM EXAM_TASK t
JOIN EXAM_REPORT r ON t.EXAM_TASK_ID = r.EXAM_TASK_ID
WHERE t.IS_DEL=0 AND r.IS_DEL=0
  AND t.SYSTEM_SOURCE_NO='@system'
  AND t.EXAM_TASK_STATUS>=50
  AND CAST(t.REGISTER_AT AS DATE)='@date'
  AND r.REPORTER_NAME IS NOT NULL
GROUP BY r.REPORTER_NAME
ORDER BY Count DESC;
```

### 4. 按收费项目统计（内镜科用）
```sql
SELECT ri.EXAM_ITEM_NAME, COUNT(DISTINCT t.EXAM_TASK_ID) AS Count
FROM EXAM_TASK t
JOIN EXAM_REPORT r ON t.EXAM_TASK_ID = r.EXAM_TASK_ID
LEFT JOIN EXAM_CHARGE_ITEM ri ON t.EXAM_TASK_ID = ri.EXAM_TASK_ID AND ri.IS_DEL=0
WHERE t.IS_DEL=0 AND r.IS_DEL=0
  AND t.SYSTEM_SOURCE_NO='@system'
  AND t.EXAM_TASK_STATUS>=50
  AND CAST(t.REGISTER_AT AS DATE)='@date'
  AND r.REPORTER_NAME IS NOT NULL
GROUP BY ri.EXAM_ITEM_NAME
ORDER BY Count DESC;
```

---

## 验证公式

### 放射科（RIS）
| 组别 | 公式 |
|------|------|
| 普放组 | DR + 钼靶 + 造影 |
| CT组 | CT平扫 + CT增强 |
| MRI组 | MRI平扫 + MRA + MRV + MRU + MRCP + MRS |
| **总计** | 普放组 + CT组 + MRI组 = 总数据 |

### 内镜科（EIS）
| 组别 | 公式 |
|------|------|
| 胃镜 | 无痛胃镜 + 普通胃镜 |
| 肠镜 | 无痛肠镜 + 普通肠镜 |

---

## 已验证数据（参考）

### 放射科（RIS）
| 日期 | 总数据 | 普放组 | CT组 | MRI组 | 验证 |
|------|--------|--------|------|-------|------|
| 4月1日 | 539条 | 186条 | 270条 | 83条 | ✅ |
| 4月2日 | 500条 | 166条 | 266条 | 68条 | ✅ |

---

## 使用示例

### 用户请求
```
帮我统计4月1日的放射科工作量
```

### Agent执行
1. 读取config.json中的数据库连接信息
2. 读取rules.json中的统计规则
3. 执行总数据量查询
4. 执行按检查类别统计
5. 按规则分类汇总
6. 验证组内公式
7. 生成报告

### 输出
```
=== WiNEX 统计验证报告 ===
日期：2026-04-01 | 放射科（RIS）

【总数据】539条

【各组数据】
普放组：186条（DR:180 + 钼靶:3 + 造影:3）
CT组：270条（CT平扫:229 + CT增强:41）
MRI组：83条（MRI平扫:83）

【验证结果】
✓ 普放组 + CT组 + MRI组 = 539条
✓ 验证通过

【各医生工作量】
1. 张银川：45条
2. 周亮：38条
...
```

---

## 配置文件

| 文件 | 说明 |
|------|------|
| config.json | 数据库连接 + Schema + 查询模板 |
| rules.json | 统计规则 + 分类映射 |
| README.md | 详细使用指南 |

---

## 更新日志

### v1.2.0 (2026-04-23)
- 整合Schema信息到config.json
- 添加SQL查询模板
- 优化快速统计流程
- 保持最少2日验证要求